<link rel="shortcut icon" href="{{ asset('img/logo/Asset 1.ico') }}">
