<!-- Fonts -->
<link rel="preconnect" href="https://fonts.googleapis.com" />
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
<link
    href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap"
    rel="stylesheet" />

<!-- Icons. Uncomment required icon fonts -->
{{-- <link rel="stylesheet" href="{{ asset('../assets/vendor/fonts/boxicons.css')}}" /> --}}
{{-- <link href='https://unpkg.com/boxicons@2.1.2/css/boxicons.min.css' rel='stylesheet'> --}}
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
{{-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous">
</script> --}}




<link rel="stylesheet" href="{{ asset('/vendor/css/datatables-bootsrap5.css') }}">
{{-- <link rel="stylesheet" href="https://cdn.datatables.net/1.13.7/css/jquery.dataTables.css" /> --}}
<link rel="stylesheet" href="{{ asset('/vendor/css/tweetbootstrap.css') }}">
{{-- <link rel="stylesheet" href="{{ asset('/vendor/css/animate.css')}}"> --}}
<link rel="stylesheet" href="{{ asset('/vendor/fonts/boxicons.css') }}">
{{-- <link rel="stylesheet" href="{{ asset('/vendor/css/boxicon.css')}}"> --}}

<!-- Core CSS -->
<link rel="stylesheet" href="{{ asset('/vendor/css/core.css') }}" class="template-customizer-core-css" />

<link rel="stylesheet" href="{{ asset('/vendor/css/datatable.css') }}" class="template-customizer-core-css" />
<link rel="stylesheet" href="{{ asset('/vendor/css/theme-default.css') }}" class="template-customizer-theme-css" />
<link rel="stylesheet" href="{{ asset('/css/demo.css') }}" />

<!-- Vendors CSS -->
<link rel="stylesheet" href="{{ asset('/vendor/libs/perfect-scrollbar/perfect-scrollbar.css') }}" />
<link rel="stylesheet" href="{{ asset('/vendor/libs/apex-charts/apex-charts.css') }}" />
<script src="/vendor/libs/jquery/jquery.js"></script>


{{-- <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></> --}}
<!-- Page CSS -->
<!-- Page -->

<!-- Helpers -->
<script src="{{ asset('/vendor/js/helpers.js') }}"></script>

<!--! Template customizer & Theme config files MUST be included after core stylesheets and helpers.js in the <head> section -->
<!--? Config:  Mandatory theme config file contain global vars & default theme options, Set your preferred theme option in this file.  -->
<script src="{{ asset('/js/config.js') }}"></script>

{{-- Terbilang --}}
@if (Request::is('gaji/slip/detail') || Request::is('gaji/slip/print') || Request::is('gaji/*/view'))
    <script type="module" src="{{ asset('js/numbertolisterner.js') }}"></script>
    {{-- @include('') --}}
@endif
@if (Request::is('gaji/*/view') ||
        Request::is('gaji/submission/store') ||
        Request::is('gaji/submission/*/update') ||
        Request::is('gaji'))
    <link rel="stylesheet" href="{{ asset('vendor/libs/bootstrap-datepicker/bootstrap-datepicker.css') }}" />
@endif
