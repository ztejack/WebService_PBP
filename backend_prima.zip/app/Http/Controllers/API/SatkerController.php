<?php

namespace App\Http\Controllers;

use App\Models\satker;
use App\Http\Requests\StoresatkerRequest;
use App\Http\Requests\UpdatesatkerRequest;

class SatkerController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\StoresatkerRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoresatkerRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\satker  $satker
     * @return \Illuminate\Http\Response
     */
    public function show(satker $satker)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\satker  $satker
     * @return \Illuminate\Http\Response
     */
    public function edit(satker $satker)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\UpdatesatkerRequest  $request
     * @param  \App\Models\satker  $satker
     * @return \Illuminate\Http\Response
     */
    public function update(UpdatesatkerRequest $request, satker $satker)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\satker  $satker
     * @return \Illuminate\Http\Response
     */
    public function destroy(satker $satker)
    {
        //
    }
}
