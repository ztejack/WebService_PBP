<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ParamPPHController extends Controller
{
    //
}
