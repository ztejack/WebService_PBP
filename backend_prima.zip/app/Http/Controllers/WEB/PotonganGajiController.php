<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PotonganGajiController extends Controller
{
    //
}
